package com.example.myapplication

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var score : TextView
    private lateinit var binding: ActivityMainBinding
    var sc :Int = 0;
    lateinit var viewModel: ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        score = binding.tvScore
        val teal = binding.btTealt
        val black = binding.btBlack
        val purple = binding.btPurple
        val white = binding.btWhite
        val reset = binding.btReset
        teal.setOnClickListener {
            updateRe("#FF03DAC5")
        }
        black.setOnClickListener {
            updateRe("#FF000000")
        }
        purple.setOnClickListener {
            updateRe("#FFBB86FC")
        }
        white.setOnClickListener {
            updateRe("#ffffff")
        }
        reset.setOnClickListener {
           reset()
        }


        viewModel = ViewModelProviders.of(this).get(ViewModel::class.java)
        val bird = com.example.myapplication.db.Entity(0,"0","#4868ea")
        viewModel.insertBird(bird)

        showColor()

    }
    fun showColor()
    {

        viewModel.getBirdObserver().observe(this, Observer {
            val  data = it
            score.text = data.score
            sc = data.score.toInt()
            score.setTextColor(Color.parseColor(data.color))
        })
    }
    fun updateRe(color: String)
    {
        sc +=1
        val bird = com.example.myapplication.db.Entity(1, sc.toString(),color)
        viewModel.updateBird(bird)
        score.text = sc.toString()

    }

    fun reset()
    {
        val bird = com.example.myapplication.db.Entity(1, "0","#4868ea")
        viewModel.updateBird(bird)
        sc = 0
        score.text = sc.toString()
        score.setTextColor(Color.parseColor("#4868ea"))
    }

}

