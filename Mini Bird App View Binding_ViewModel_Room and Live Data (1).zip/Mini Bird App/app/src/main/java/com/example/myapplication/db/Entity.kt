package com.example.myapplication.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bird")
data class Entity (
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val id : Int= 0,
    @ColumnInfo(name = "score") val score:String,
    @ColumnInfo(name = "color") val color:String
    )