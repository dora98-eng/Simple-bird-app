package com.example.myapplication

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.myapplication.db.Entity
import com.example.myapplication.db.RoomAppDb

class ViewModel(app: Application):AndroidViewModel(app)
{
    lateinit var bird: MutableLiveData<Entity>
    init {
        bird = MutableLiveData()

    }
    fun getBirdObserver():MutableLiveData<Entity>
    {
        return bird
    }
    fun getAllBird(){
     val dao =   RoomAppDb.getAppDatabase((getApplication()))?.Dao()
     val  list =  dao?.getBird()
        bird.postValue(list)
    }
    fun insertBird(entity: Entity)
    {
      val dao =   RoomAppDb.getAppDatabase(getApplication())?.Dao()
        dao?.insertBird(entity)
        getAllBird()
    }
    fun updateBird(entity: Entity)
    {
      val dao =   RoomAppDb.getAppDatabase(getApplication())?.Dao()
        dao?.updateBird(entity)
        getAllBird()
    }
    fun deleteBird(entity: Entity)
    {
      val dao =   RoomAppDb.getAppDatabase(getApplication())?.Dao()
        dao?.deleteBird(entity)
        getAllBird()
    }
}