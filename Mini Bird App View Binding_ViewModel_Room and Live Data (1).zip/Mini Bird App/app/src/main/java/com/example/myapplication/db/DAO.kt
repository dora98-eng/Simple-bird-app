package com.example.myapplication.db

import androidx.room.*

@Dao
interface DAO {

    @Query("SELECT * FROM bird ")
    fun getBird(): Entity?

    @Insert
    fun insertBird(bird: Entity?)

    @Delete
    fun deleteBird(bird: Entity?)

    @Update
    fun updateBird(bird: Entity?)

}